﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartMeetingRoom1.Dtos;
using SmartMeetingRoom1.Interfaces;
using System.Security.Claims;

namespace SmartMeetingRoom1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class MinutesController : ControllerBase
    {
        private readonly IMinute _service;

        public MinutesController(IMinute service) => _service = service;

        // GET /api/minutes/5
        [HttpGet("{id:int}")]
        public async Task<ActionResult<MinuteDto>> Get(int id)
        {
            var minute = await _service.GetByIdAsync(id);
            if (minute == null) return NotFound();
            return Ok(minute);
        }

        // GET /api/minutes/by-meeting/123
        [HttpGet("by-meeting/{meetingId:int}")]
        public async Task<ActionResult<MinuteDto>> GetByMeeting(int meetingId)
        {
            var m = await _service.GetByMeetingAsync(meetingId);
            if (m == null) return NotFound();
            return Ok(m);
        }

        // POST /api/minutes   (KEEP ONLY THIS Create)
        [HttpPost]
        [Authorize(Roles = "Admin,Employee")]
        public async Task<ActionResult<MinuteDto>> Create([FromBody] CreateMinuteDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            if (dto.MeetingId <= 0) return BadRequest("MeetingId is required.");

            // optional: creator from token (if your service needs it)
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            _ = int.TryParse(userIdStr, out var userId);

            try
            {
                // avoid duplicate minutes for the same meeting
                var existing = await _service.GetByMeetingAsync(dto.MeetingId);
                if (existing != null)
                    return CreatedAtAction(nameof(Get), new { id = existing.Id }, existing);

                var created = await _service.CreateAsync(dto /* pass userId if used */);
                return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT /api/minutes/5
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin,Employee")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateMinuteDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var ok = await _service.UpdateAsync(id, dto);
            if (!ok) return NotFound();
            return NoContent();
        }

        // DELETE /api/minutes/5
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin,Employee")]
        public async Task<IActionResult> Delete(int id)
        {
            var ok = await _service.DeleteAsync(id);
            if (!ok) return NotFound();
            return NoContent();
        }

        // Optional endpoint used by the page if present
        // POST /api/minutes/5/finalize
        [HttpPost("{id:int}/finalize")]
        public IActionResult Finalize(int id)
        {
            // set a flag / generate pdf later, etc.
            return NoContent();
        }

    }
}
