﻿// ======== auth.js ========
const API_BASE = "/api";
const TOKEN_KEY = "smr_access_token";
const RTOKEN_KEY = "smr_refresh_token";
const ADMIN_HOME = "/admin.html";   // <— change if your admin page has another name
const USER_HOME = "/index.html";

// ---- helpers ----
function storeTokens(json, remember) {
    const access = json.AccessToken || json.accessToken || json.token || json.jwt;
    const refresh = json.RefreshToken || json.refreshToken || null;
    if (!access) throw new Error("Token not found in response.");

    const S = remember ? localStorage : sessionStorage;
    S.setItem(TOKEN_KEY, access);
    if (refresh) S.setItem(RTOKEN_KEY, refresh);
    return access;
}

function readToken() {
    return (
        localStorage.getItem(TOKEN_KEY) ||
        sessionStorage.getItem(TOKEN_KEY) ||
        ""
    );
}

async function fetchMe(token) {
    const res = await fetch(`${API_BASE}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error("Failed to load profile.");
    return res.json(); // { id, userName, email, roles: [...] }
}

function redirectByRoles(roles) {
    const isAdmin = Array.isArray(roles) && roles.some(r => r.toLowerCase() === "admin");
    window.location.href = isAdmin ? ADMIN_HOME : USER_HOME;
}

// ---- wire up the login form ----
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("loginForm");
    if (!form) return;

    const emailEl = document.getElementById("email");
    const passEl = document.getElementById("password");
    const rememberEl = document.getElementById("rememberMe");
    const errEl = document.getElementById("error");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        if (errEl) errEl.textContent = "";

        const email = (emailEl?.value || "").trim();
        const password = passEl?.value || "";
        const remember = !!(rememberEl && rememberEl.checked);

        try {
            const res = await fetch(`${API_BASE}/auth/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userNameOrEmail: email, password })
            });

            if (!res.ok) {
                let msg = "";
                try {
                    const ct = res.headers.get("content-type") || "";
                    if (ct.includes("application/json")) {
                        const j = await res.json();
                        msg = j?.title || j?.detail || j?.message || j?.error || JSON.stringify(j);
                    } else {
                        msg = await res.text();
                    }
                } catch { }
                throw new Error(msg || `Login failed (${res.status})`);
            }


            const data = await res.json();
            const token = storeTokens(data, remember);

            // decide where to go
            try {
                const me = await fetchMe(token);
                redirectByRoles(me.roles || []);
            } catch {
                window.location.href = USER_HOME;
            }
        } catch (err) {
            if (errEl) errEl.textContent = err.message || "Login failed.";
            else alert(err.message || "Login failed.");
        }
    });

    // Optional: already logged in? auto-redirect from login page
    (async () => {
        const token = readToken();
        if (!token) return;
        try {
            const me = await fetchMe(token);
            redirectByRoles(me.roles || []);
        } catch {
            // invalid/expired token — clear and stay on login
            localStorage.removeItem(TOKEN_KEY);
            localStorage.removeItem(RTOKEN_KEY);
            sessionStorage.removeItem(TOKEN_KEY);
            sessionStorage.removeItem(RTOKEN_KEY);
        }
    })();
});
// ======== end auth.js ========<!-- load last -->

