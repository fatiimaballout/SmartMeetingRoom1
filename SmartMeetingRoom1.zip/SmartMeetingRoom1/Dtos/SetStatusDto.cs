﻿namespace SmartMeetingRoom1.Dtos
{
    public class SetStatusDto
    {
        public string Status { get; set; } = "Pending";
    }
}
