﻿namespace SmartMeetingRoom1.Dtos
{
    public class UpdateMinuteDto
    {
        public string Discussion { get; set; }
        public string Decisions { get; set; }
    }
}
