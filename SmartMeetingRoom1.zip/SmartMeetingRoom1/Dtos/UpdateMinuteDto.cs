﻿namespace SmartMeetingRoom1.Dtos
{
    public class UpdateMinuteDto
    {
        public string Notes { get; set; } = string.Empty;
        public string Discussion { get; set; } = string.Empty;
        public string Decisions { get; set; } = string.Empty;
    }
}
