﻿namespace SmartMeetingRoom1.Dtos
{
    public class UpdateActionItemDto
    {
        public string? Description { get; set; }
        public string? Status { get; set; }
        public DateTime? DueDate { get; set; }     // <- nullable
    }
}
