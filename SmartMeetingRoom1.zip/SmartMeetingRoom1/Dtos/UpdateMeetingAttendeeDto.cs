﻿namespace SmartMeetingRoom1.Dtos
{
    public class UpdateMeetingAttendeeDto
    {
        public string Status { get; set; }
    }
}
