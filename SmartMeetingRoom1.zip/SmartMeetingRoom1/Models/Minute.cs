﻿using SmartMeetingRoom1.Models;

public class Minute
{
    public int Id { get; set; }

    public int MeetingId { get; set; }
    public Meeting Meeting { get; set; } = null!;

    public int CreatorId { get; set; }                     // Identity user id
    public ApplicationUser Creator { get; set; } = null!;

    public string Discussion { get; set; } = string.Empty;
    public string Decisions { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;

    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;

    public ICollection<ActionItem> ActionItems { get; set; } = new List<ActionItem>();
    public ICollection<Attachment> Attachments { get; set; } = new List<Attachment>();
}
