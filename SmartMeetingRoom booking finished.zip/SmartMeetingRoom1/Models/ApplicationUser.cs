﻿using Microsoft.AspNetCore.Identity;
namespace SmartMeetingRoom1.Models
{
    public class ApplicationUser : IdentityUser<int> { }
    
}
