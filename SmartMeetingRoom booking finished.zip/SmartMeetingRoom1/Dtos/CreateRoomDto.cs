﻿namespace SmartMeetingRoom1.Dtos
{
    public class CreateRoomDto
    {
        public string Name { get; set; }
        public int Capacity { get; set; }
        public string Location { get; set; }
        public string Features { get; set; }
    }
}
